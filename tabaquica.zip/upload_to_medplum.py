#!/usr/bin/env python3
"""
Script para crear recursos FHIR R4 en Medplum para el Programa de Cesación Tabáquica
EPA Bienestar IA - Life's Essential 8

Uso:
    python upload_to_medplum.py

Requisitos:
    - requests library: pip install requests --break-system-packages
    - Credenciales de Medplum configuradas
"""

import json
import os
from typing import Dict, List, Tuple
import requests
from datetime import datetime

# Configuración
MEDPLUM_BASE_URL = "https://api.epa-bienestar.com.ar/fhir/R4"
# TODO: Configurar autenticación - usar variables de entorno en producción
# MEDPLUM_CLIENT_ID = os.getenv('MEDPLUM_CLIENT_ID')
# MEDPLUM_CLIENT_SECRET = os.getenv('MEDPLUM_CLIENT_SECRET')

# Orden de creación de recursos (dependencias)
RESOURCE_ORDER = [
    'observationDefinition',
    'activityDefinition',
    'planDefinition',
    'questionnaireFagerstrom',
    'questionnaireMEPA',
    'carePlanTemplate'
]

RESOURCE_MAPPING = {
    'observationDefinition': 'ObservationDefinition',
    'activityDefinition': 'ActivityDefinition',
    'planDefinition': 'PlanDefinition',
    'questionnaireFagerstrom': 'Questionnaire',
    'questionnaireMEPA': 'Questionnaire',
    'carePlanTemplate': 'CarePlan'
}

class MedplumUploader:
    """Clase para manejar la carga de recursos FHIR a Medplum"""
    
    def __init__(self, base_url: str):
        self.base_url = base_url
        self.session = requests.Session()
        self.results = []
        
    def authenticate(self):
        """
        Autenticar con Medplum usando OAuth2
        TODO: Implementar autenticación real
        """
        # En producción, implementar OAuth2 flow
        # auth_url = f"{self.base_url}/auth/token"
        # response = self.session.post(auth_url, data={...})
        # self.session.headers.update({'Authorization': f'Bearer {token}'})
        
        # Por ahora, asumir que la autenticación se maneja externamente
        print("⚠️  NOTA: Asegúrate de tener configurada la autenticación con Medplum")
        print("   Puedes usar Medplum CLI o configurar tokens OAuth2\n")
        
    def load_resource(self, filename: str) -> Dict:
        """Cargar recurso desde archivo JSON"""
        filepath = f"/home/claude/{filename}"
        with open(filepath, 'r', encoding='utf-8') as f:
            return json.load(f)
    
    def create_resource(self, resource_type: str, resource_data: Dict) -> Tuple[bool, str, Dict]:
        """
        Crear recurso en Medplum
        
        Returns:
            Tuple[bool, str, Dict]: (success, message, response_data)
        """
        url = f"{self.base_url}/{resource_type}"
        
        try:
            # Simular creación (comentar esto en producción)
            print(f"   📤 POST {url}")
            print(f"      ID: {resource_data.get('id', 'N/A')}")
            print(f"      Name: {resource_data.get('name', resource_data.get('title', 'N/A'))}")
            
            # En producción, descomentar esto:
            # response = self.session.post(url, json=resource_data)
            # response.raise_for_status()
            # return True, "Recurso creado exitosamente", response.json()
            
            # Simulación
            return True, "Recurso preparado (modo simulación)", resource_data
            
        except requests.exceptions.HTTPError as e:
            error_msg = f"Error HTTP: {e.response.status_code}"
            try:
                error_detail = e.response.json()
                error_msg += f" - {json.dumps(error_detail, indent=2)}"
            except:
                error_msg += f" - {e.response.text}"
            return False, error_msg, {}
        except Exception as e:
            return False, f"Error: {str(e)}", {}
    
    def upload_all(self):
        """Subir todos los recursos en orden"""
        print("=" * 80)
        print("INICIO DE CARGA DE RECURSOS FHIR A MEDPLUM")
        print(f"Timestamp: {datetime.now().isoformat()}")
        print("=" * 80)
        print()
        
        for resource_key in RESOURCE_ORDER:
            resource_type = RESOURCE_MAPPING[resource_key]
            filename = f"fhir_{resource_key}.json"
            
            print(f"📦 Procesando: {resource_key}")
            print(f"   Tipo FHIR: {resource_type}")
            
            try:
                resource_data = self.load_resource(filename)
                success, message, response = self.create_resource(resource_type, resource_data)
                
                self.results.append({
                    'resource_key': resource_key,
                    'resource_type': resource_type,
                    'success': success,
                    'message': message,
                    'timestamp': datetime.now().isoformat()
                })
                
                if success:
                    print(f"   ✅ {message}")
                else:
                    print(f"   ❌ {message}")
                    
            except FileNotFoundError:
                print(f"   ❌ Archivo no encontrado: {filename}")
                self.results.append({
                    'resource_key': resource_key,
                    'resource_type': resource_type,
                    'success': False,
                    'message': 'Archivo no encontrado',
                    'timestamp': datetime.now().isoformat()
                })
            except Exception as e:
                print(f"   ❌ Error inesperado: {str(e)}")
                self.results.append({
                    'resource_key': resource_key,
                    'resource_type': resource_type,
                    'success': False,
                    'message': f'Error inesperado: {str(e)}',
                    'timestamp': datetime.now().isoformat()
                })
            
            print()
        
        self.print_summary()
        self.save_results()
    
    def print_summary(self):
        """Imprimir resumen de resultados"""
        print("=" * 80)
        print("RESUMEN DE CARGA")
        print("=" * 80)
        print()
        
        successful = sum(1 for r in self.results if r['success'])
        failed = len(self.results) - successful
        
        print(f"✅ Exitosos: {successful}")
        print(f"❌ Fallidos: {failed}")
        print(f"📊 Total: {len(self.results)}")
        print()
        
        if failed > 0:
            print("Recursos fallidos:")
            for result in self.results:
                if not result['success']:
                    print(f"  - {result['resource_key']}: {result['message']}")
            print()
    
    def save_results(self):
        """Guardar resultados en archivo JSON"""
        results_file = "/home/claude/medplum_upload_results.json"
        with open(results_file, 'w', encoding='utf-8') as f:
            json.dump({
                'timestamp': datetime.now().isoformat(),
                'base_url': self.base_url,
                'results': self.results
            }, f, indent=2, ensure_ascii=False)
        print(f"📄 Resultados guardados en: {results_file}")
        print()

def create_example_patient_careplan():
    """
    Crear ejemplo de cómo instanciar un CarePlan para un paciente real
    """
    example = {
        "resourceType": "CarePlan",
        "instantiatesCanonical": [
            "http://epa-bienestar.com.ar/PlanDefinition/smoking-cessation-4-steps-grupo-b"
        ],
        "status": "active",
        "intent": "plan",
        "category": [{
            "coding": [{
                "system": "http://snomed.info/sct",
                "code": "225323000",
                "display": "Smoking cessation education"
            }]
        }],
        "title": "Plan de Cesación Tabáquica - María González",
        "description": "Plan personalizado de 12 semanas para cesación tabáquica",
        "subject": {
            "reference": "Patient/ejemplo-maria-gonzalez-32",
            "display": "María González"
        },
        "period": {
            "start": "2026-01-13",
            "end": "2026-04-06"
        },
        "created": "2026-01-13",
        "author": {
            "reference": "Practitioner/ejemplo-dra-aquieri",
            "display": "Dra. Analía Aquieri"
        },
        "careTeam": [{
            "reference": "CareTeam/equipo-cardiologia-epa"
        }],
        "addresses": [{
            "reference": "Condition/tabaquismo-maria-gonzalez"
        }],
        "goal": [{
            "reference": "Goal/cesacion-completa-maria"
        }],
        "activity": [{
            "outcomeReference": [{
                "reference": "Observation/fagerstrom-baseline-maria"
            }],
            "detail": {
                "kind": "ServiceRequest",
                "instantiatesCanonical": [
                    "http://epa-bienestar.com.ar/ActivityDefinition/smoking-cessation-program-grupo-b"
                ],
                "code": {
                    "coding": [{
                        "system": "http://snomed.info/sct",
                        "code": "225323000",
                        "display": "Smoking cessation education"
                    }]
                },
                "status": "in-progress",
                "scheduledPeriod": {
                    "start": "2026-01-13",
                    "end": "2026-04-06"
                },
                "performer": [{
                    "reference": "Practitioner/ejemplo-dra-aquieri"
                }],
                "description": "Programa completo de cesación tabáquica de 12 semanas"
            }
        }]
    }
    
    filepath = "/home/claude/example_patient_careplan.json"
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(example, f, indent=2, ensure_ascii=False)
    
    print("=" * 80)
    print("EJEMPLO DE CAREPLAN PARA PACIENTE")
    print("=" * 80)
    print()
    print(f"✅ Ejemplo creado en: {filepath}")
    print()
    print("Para crear un CarePlan para un paciente real:")
    print("1. Reemplazar las referencias de Patient, Practitioner, etc.")
    print("2. POST a: https://api.epa-bienestar.com.ar/fhir/R4/CarePlan")
    print()

def print_integration_guide():
    """Imprimir guía de integración"""
    print("=" * 80)
    print("GUÍA DE INTEGRACIÓN CON MEDPLUM")
    print("=" * 80)
    print()
    
    print("1️⃣  AUTENTICACIÓN")
    print("   Configurar OAuth2 con Medplum:")
    print("   - Client ID y Client Secret")
    print("   - Obtener token de acceso")
    print()
    
    print("2️⃣  CREAR RECURSOS BASE (EJECUTAR ESTE SCRIPT)")
    print("   python upload_to_medplum.py")
    print()
    
    print("3️⃣  CREAR PACIENTE")
    print("   POST /fhir/R4/Patient")
    print("   {")
    print('     "resourceType": "Patient",')
    print('     "identifier": [...],')
    print('     "name": [...],')
    print('     "birthDate": "1992-01-15",')
    print('     "gender": "female"')
    print("   }")
    print()
    
    print("4️⃣  EVALUAR CON CUESTIONARIO FAGERSTRÖM")
    print("   GET /fhir/R4/Questionnaire/fagerstrom-nicotine-dependence-test")
    print("   Paciente completa -> POST /fhir/R4/QuestionnaireResponse")
    print()
    
    print("5️⃣  CREAR CAREPLAN PARA PACIENTE")
    print("   POST /fhir/R4/CarePlan")
    print("   Ver: example_patient_careplan.json")
    print()
    
    print("6️⃣  SEGUIMIENTO CON OBSERVACIONES")
    print("   POST /fhir/R4/Observation (smoking-status)")
    print("   - Baseline: Current smoker")
    print("   - Semana 2: Former smoker (quit <1 month)")
    print("   - Semana 8: Former smoker (quit 1-6 months)")
    print("   - Mes 12: Former smoker (>12 months) ✅")
    print()
    
    print("7️⃣  TRACKING CON TASKS")
    print("   POST /fhir/R4/Task")
    print("   - Cada actividad del plan genera Tasks")
    print("   - Status: requested -> in-progress -> completed")
    print()
    
    print("8️⃣  DASHBOARD Y REPORTES")
    print("   GET /fhir/R4/Observation?patient=X&code=72166-2")
    print("   GET /fhir/R4/CarePlan?patient=X&status=active")
    print("   GET /fhir/R4/QuestionnaireResponse?questionnaire=fagerstrom")
    print()

if __name__ == "__main__":
    print()
    print("🏥 EPA BIENESTAR IA - PROGRAMA DE CESACIÓN TABÁQUICA")
    print("📋 Life's Essential 8 - American Heart Association")
    print()
    
    # Crear uploader
    uploader = MedplumUploader(MEDPLUM_BASE_URL)
    
    # Autenticar (placeholder)
    uploader.authenticate()
    
    # Subir todos los recursos
    uploader.upload_all()
    
    # Crear ejemplo de CarePlan para paciente
    create_example_patient_careplan()
    
    # Imprimir guía de integración
    print_integration_guide()
    
    print("=" * 80)
    print("PROCESO COMPLETADO")
    print("=" * 80)
    print()
    print("📚 Documentación adicional:")
    print("   - Medplum Docs: https://www.medplum.com/docs")
    print("   - FHIR R4 Spec: https://hl7.org/fhir/R4/")
    print("   - Life's Essential 8: https://www.heart.org/lifes-essential-8")
    print()
